package com.example.rannumgenerate

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import java.util.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val generateButton = findViewById<Button>(R.id.generateButton)
        val minRange = findViewById<TextView>(R.id.minRange)
        val maxRange = findViewById<TextView>(R.id.maxRange)
        val resultTextView = findViewById<TextView>(R.id.resultTextView)

        generateButton.setOnClickListener{
            val tempMin = minRange.text.toString()
            val tempMax = maxRange.text.toString()
            if (!tempMin.equals("") && !tempMax.equals("")){
                var min:Int =  tempMin.toInt()
                var max:Int =  tempMax.toInt()
                var output:Int = Random().nextInt((max - min) +1) + min
                resultTextView.setText("" + output)
            }
        }
    }
}